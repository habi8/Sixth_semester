package com.example;

public class UserRepository {
    public User  getUserByEmail(String email){
            return new User();
    }
}
