package com.example;

public class Hashing {
    public String hashing(String password){
        return "as74rwcwe9jdsdd7237y237rthfbhj";
    }
}
