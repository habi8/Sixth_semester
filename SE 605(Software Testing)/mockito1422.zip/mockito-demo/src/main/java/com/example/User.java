package com.example;

public class User {
    String email;
    String pass;
}
